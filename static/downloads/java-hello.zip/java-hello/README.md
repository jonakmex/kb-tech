# Java Hello World (sin build tool)

## Ejecutar
Requisitos: JDK 17+ (o 11+)

```bash
cd examples/java-hello
javac HelloWorld.java
java HelloWorld