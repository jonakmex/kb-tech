public interface Shape {
  double area();
}

