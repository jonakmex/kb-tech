# Java Polomorfismo (sin build tool)

## Metadata

- Lenguaje: Java
- Conceptos: SOLID, interfaz, polimorfismo

## Ejecutar

Requisitos: JDK 17+ (o 11+)

```bash
cd examples/java-polomorfismo
javac *.java
java PolymorphismExample
```

